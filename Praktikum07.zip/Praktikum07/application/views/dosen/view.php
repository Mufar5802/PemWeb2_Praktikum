<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <h2 class="text-center mt-3"><?php echo $judul ?> </h2>
    <div class="card-body table-responsive p-3">
        <table class="table table-hover text-nowrap">
            <thead>
                <tr>
                    <th>NIDN</th>
                    <th>Nama Dosen</th>
                    <th>Gender</th>
                    <th>Tempat Lahir</th>
                    <th>Tanggal Lahir</th>
                    <th>Prodi</th>
                    <th>Pendidikan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    echo '<tr>';
                    echo '<td>'. $dsn->nidn .'</td>';
                    echo '<td>'. $dsn->nama .'</td>';
                    echo '<td>'. $dsn->gender .'</td>';
                    echo '<td>'. $dsn->tmp_lahir .'</td>';
                    echo '<td>'. $dsn->tgl_lahir .'</td>';
                    echo '<td>'. $dsn->prodi .'</td>';
                    echo '<td>'. $dsn->pendidikan .'</td>';
                    echo '</tr>';       
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>