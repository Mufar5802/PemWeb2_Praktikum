<h2><?php echo $title?></h2>
<h1>Selamat Datang <?=$nama?> </h1>