<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Mahasiswa extends CI_Controller {
    public function index()
    {
    $this->load->model('mahasiswa_model','mhs1');
    $this->mhs1->id=1;
    $this->mhs1->nim='0110121062';
    $this->mhs1->nama='Muhammad Farhat';
    $this->mhs1->gender='Laki-Laki';
    $this->mhs1->ipk=3.97;

    $this->load->model('mahasiswa_model','mhs2');
    $this->mhs2->id=2;
    $this->mhs2->nim='0110121071';
    $this->mhs2->nama='Muhammad Syahid Bayanussabil';
    $this->mhs2->gender='Laki-Laki';
    $this->mhs2->ipk=4.00;

    $list_mhs = [$this->mhs1, $this->mhs2];
    $data['list_mhs']=$list_mhs;

    $this->load->view('mahasiswa/index',$data);

 }
}
