<?php

class Dosen_model extends CI_Model {
    public $nidn,
           $id,
           $nama,
           $pendidikan,
           $gender;

}