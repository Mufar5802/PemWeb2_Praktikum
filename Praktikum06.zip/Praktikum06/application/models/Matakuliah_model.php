<?php

class Matakuliah_model extends CI_Model {
    public $nama,
           $sks,
           $kode;
}