<?php 
 class User_model extends CI_Model{

     private $table = "user";
     
     public function getAll(){
         $query = $this->db->get($this->table);
         return $query->result();
     }

     public function findById($id){
         $this->db->where('id',$id);
         $query = $this->db->get($this->table);
         return $query->row();
     }

     public function login($uname, $pass){
         $sql = "SELECT * FROM user WHERE username=? 
            and password=MD5(?)";  
         $data = [$uname, $pass];
         $query = $this->db->query($sql, $data);

         return $query->row();
     }

     public function register($data){
        //INSERT INTO user (id, username, password, email, role, created_at, last_login)
        //VALUES (default, 'Siswa2', MD5('67890'), 'siswa2@sttnf.ac.id', 'MAHASISWA', now(), now());
        $sql = "INSERT INTO user (id, username, password, email, role, created_at, last_login)
        VALUES (default,?,MD5(?),?,?,now(),now())";
        $this->db->query($sql, $data); 
    }
    }
